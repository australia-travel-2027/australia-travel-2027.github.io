document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
window.addEventListener('beforeprint', () => document.querySelectorAll('details').forEach(item => { item.dataset.wasOpen = String(item.open); item.open = true; }));
window.addEventListener('afterprint', () => document.querySelectorAll('details').forEach(item => { item.open = item.dataset.wasOpen === 'true'; }));
